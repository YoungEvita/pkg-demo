self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2e6490b65cf9358c53f9",
    "url": "/css/app.dacd2f04.css"
  },
  {
    "revision": "65962d53afe6d9878c85",
    "url": "/css/chunk-vendors.de05c3c7.css"
  },
  {
    "revision": "c4d40fad2407f00ba65e03562757ec89",
    "url": "/index.html"
  },
  {
    "revision": "2e6490b65cf9358c53f9",
    "url": "/js/app.c05d5c91.js"
  },
  {
    "revision": "65962d53afe6d9878c85",
    "url": "/js/chunk-vendors.93bf3705.js"
  },
  {
    "revision": "92c481f3ee3a3507e71a9616a7ff91ac",
    "url": "/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
]);